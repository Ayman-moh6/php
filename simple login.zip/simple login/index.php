<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>تسجيل دخول</title>
  </head>
  <style>
@import "https://use.fontawesome.com/releases/v5.5.0/css/all.css";

  body {
    margin: 0;
    background-image:url("back.png");
    background-position: center; /* Center the image */
    background-attachment: fixed;
}

.creat {
overflow: hidden;
font-size: 130%;
font-family:verdana

}


/* Style the top navigation bar */
.signin {
  overflow: hidden;
  font-size: 100%;
font-family:verdana
}

/* Style the topnav links */
.signin a {
  float: right;
  display: block;
  color: black;
  font-size: 120%;
  text-align: center;
  padding: 5px 14px;
  text-decoration: none;

}


  /* Change color on hover */
  .signin a:hover {
    font-size: 120%;
    color: #535353;
  }


/* Style the topnav links */
.creat a {
width: 120%;
background: none;
color:#656565;

padding: 5px;
font-size: 18px;
cursor: pointer;
margin: 12px 0;

}

.right1{
  float: right;
  text-align: right;
}






  .login-box{
    width: 280px;
    position: absolute;
    top: 35%;
    padding-top: 100px;
    left: 50%;
    transform: translate(-50%,-50%);
    color: black;}



  /*  padding-left: 80px;*/
  .login-box h1{
    float:center;
    font-size: 33px;
    border-bottom: 6px solid #656565;
    margin-bottom: 5px;
    padding: 13px 0;
    padding-left: 35px;

  }



  .textbox{
    width: 100%;
    overflow: hidden;
    font-size: 25px;
    padding: 8px 0;
    text-align: right;

    margin: 8px 0;    border-bottom: 1px solid #656565;}




  .textbox i{
    width: 26px;
    float: right;
    text-align: right;}


  .textbox input{
    border: none;
    outline: none;
    background: none;
    color: black;
    font-size: 18px;
    width: 80%;
    text-align: right;

    margin: 10 0px;}






  .btn{
    width: 100%;
    background: none;
    border: 2px solid #656565;
    color:#656565;
    padding: 5px;
    font-size: 18px;
    cursor: pointer;
    margin: 12px 0;}

  
  .bab{
    border: 0.5px solid #ddd;
    border-radius: 30px;
    padding: 50px;
    padding-top: 1px;
    padding-bottom: 100px;
    width: 250px;
  margin-left:-25px;


}



  </style>
  <meta charset="UTF-8" />

<div class="signin">
  <a href="Wellcome">الصفحة الرئيسية</a>

</div>
  <body>
      <div class="login-box">

      <div class="bab">

            <h1>تسجيل دخول</h1>
    <div class="textbox">

      <i class="fas fa-user"></i>



        <input type="text" placeholder="إسم المستخدم">
    </div>


      <div class="textbox">
        <i class="fas fa-lock"></i>

        <input type="password" placeholder="كلمة المرور">

      </div>

      <input type="button" class="btn" value="تسجيل">
      <div class="right1">
      <div class="creat">
      <h5>لا تمتلك حساب؟إضغط<a href="sign up">هنا</a></h5>
    </div>
    </div>
</div>




</div>
</div>

  </body>
</html>
