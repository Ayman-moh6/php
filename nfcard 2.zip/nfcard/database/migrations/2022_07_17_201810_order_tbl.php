<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\QueryException;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        Schema::create('order_tbl', function (Blueprint $table) {
            $table->bigIncrements('order_id');
            $table->string('name');
            $table->biginteger('phone');
            $table->string('email');
            $table->string('city');
            $table->string('address');
            $table->string('card_name');
            $table->string('card_job');
            $table->string('url_type');
            $table->string('url');
            $table->longText('note');
            $table->date('order_date');
        });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
