<!DOCTYPE html>
<html>
    @extends('layout.head')

</html>