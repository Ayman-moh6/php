<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    use HasFactory;
    protected $table = 'order_tbl';
    public $timestamps = false;
    protected $fillable = [
        'order_id',
		'name',
        'phone',
        'email',
        'city',
        'address',
        'card_name',
        'card_job',
        'url_type',
        'url',
        'note',
        'order_date'
	];}
