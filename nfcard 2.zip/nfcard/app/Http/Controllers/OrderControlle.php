<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\order;

class OrderControlle extends Controller
{
    //
    public function getData(Request $req)
    {
        $order = new order;
        $order->order_id = null;
        $order->name = $req->name;
        $order->phone = $req->phone;
        $order->email = $req->email;
        $order->city = $req->city;
        $order->address = $req->address;
        $order->card_name = $req->card_name;
        $order->card_job = $req->card_job;
        $order->url_type = $req->url_type;
        $order->url = $req->url;
        $order->note = $req->note;
        $order->order_date = date('Y-m-d');
        $order->status = 'proc';
        $order->save();
        return redirect()->route( 'order' )->with( [ 'message' => 'تم ادراج طلبك بنجاح سيتم التواصل معك خلال 48 ساعة' ] );


    }
}