<!DOCTYPE html>
<html dir="rtl" lang="ar"> 
    <head>
      
      <link rel="shortcut icon" href="<?php echo e(asset('img/nflogo.png')); ?>">
        <style>
            body {
              text-align: right;
            }
            .order-form .container {
                  color: #4c4c4c;
                  padding: 20px;
                  box-shadow: 0 0 10px 0 rgba(0, 0, 0, .1);
                }
            
                .order-form-label {
                  margin: 8px 0 0 0;
                  font-size: 14px;
                  font-weight: bold;
                }
            
                .order-form-input {
                  width: 100%;
                  padding: 8px 8px;
                  border-width: 1px !important;
                  border-style: solid !important;
                  border-radius: 3px !important;
                  font-family: 'Open Sans', sans-serif;
                  font-size: 14px;
                  font-weight: normal;
                  font-style: normal;
                  line-height: 1.2em;
                  background-color: transparent;
                  border-color: #cccccc;
                }
            
                .btn-submit:hover {
                  background-color: #090909 !important;
                }
                .msg {
                margin: 30px auto;
                padding: 10px;
                border-radius: 5px;
                color: #3c763d;
                background: #dff0d8;
                border: 1px solid #3c763d;
                width: 100%;
                text-align: center;
            }
            </style>
    </head>
    <body style="background-color: #090909">
    
    <?php if(session()->get( 'message' )): ?>
    <div class="msg">
    <?php echo e(session()->get( 'message' )); ?>

    </div>
<?php endif; ?>
    <section class="order-form my-4 mx-4" style="background-color:white;">
        <form action="order" method="GET">
            <?php echo csrf_field(); ?>
        <div class="container pt-4">
    
          <div class="row">
            <div class="col-12">
              <h1 class="text-center" >قم بتعبئة طلب البطاقة</h1>
              <hr class="mt-1">
            </div>
            <div class="col-12">
              
              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label h4">تفاصيل المستخدم</label>
                </div>
                <div class="col-12 col-sm-6">
                </div>
              </div>

              <div class="row mx-4">
                <div class="col-12 mb-2">
                  <label class="order-form-label">الإسم الثلاثي</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="text" class="order-form-input" name="name" required>
                </div>

              </div>
    
              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label">رقم الجوال</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" name="phone" class="order-form-input" required>
                </div>
              </div>
    

              <div class="row mx-4">
                <div class="col-12 mb-2">
                  <label class="order-form-label">البريد الالكتروني</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="email" class="order-form-input" name="email" required>
                </div>

              </div>


              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label">المحافظة</label>
                </div>
                <div class="col-12 col-sm-6">
                    <select name="city" class="text-end form-select" aria-label="Default select example" required>
                        <option selected value="">قم بإختيار محافظتك</option>
                        <option value="Rafah">رفح</option>
                        <option value="khanyounis">خانيونس</option>
                        <option value="middle">الوسطى</option>
                        <option value="Gaza">غزة</option>
                      </select>                
                </div>
              </div>
    
              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label" for="date-picker-example">العنوان</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="text" name="address" class="order-form-input datepicker" placeholder="" type="text" id="date-picker-example" required>
                </div>
              </div>

              <hr class="mt-4">

              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label h4">تفاصيل البطاقة</label>
                </div>
                <div class="col-12 col-sm-6">
                </div>
              </div>


              <div class="row mx-4">
                <div class="col-12 mb-2">
                  <label class="order-form-label">الاسم (المكتوب على البطاقة بالانجليزية)</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="text" class="order-form-input" name="card_name" required>
                </div>

              </div>

              <div class="row mx-4">
                <div class="col-12 mb-2">
                  <label class="order-form-label">الوظيفة (المكتوبة على البطاقة بالانجليزية)</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="text" class="order-form-input" name="card_job">
                </div>

              </div>
              
              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="order-form-label">ماذا تريد الوضع على بطاقتك؟</label>
                </div>
                <div class="col-12 col-sm-6">
                    <select name="url_type" class="text-end form-select" aria-label="Default select example" required>
                        <option selected value="">قم بإختيار طلبك </option>
                        <option value="website">رابط موقع إلكتروتي</option>
                        <option value="social_media">حساب تواصل إجتماعي</option>
                        <option value="contact">جهة اتصال</option>
                        <option value="phone">رقم جوال</option>
                        <option value="other">أخرى</option>
                      </select>                
                </div>
              </div>

              <div class="row mx-4">
                <div class="col-12 mb-2">
                  <label class="order-form-label">رابط الموقع/رابط الحساب/تفاصيل جهة الإتصال</label>
                </div>
                <div class="col-12 col-sm-6">
                  <input type="text" class="order-form-input" name="url" required>
                </div>

              </div>

              <div class="row mt-3 mx-4">
                <div class="col-12">
                  <label class="float-right order-form-label">ملاحظات</label>
                </div>
                <div class="col-12">
                  <input type="text" name="note" class="order-form-input" placeholder="" value="">
                </div>
            </div>
            
    
              <div class="row mt-3">
                <div class="col-12">
                  <button type="submit" id="btnSubmit" class="btn btn-dark d-block mx-auto btn-submit btn-lg">اطلب</button>
                </div>
              </div>
    
            </div>
          </div>
        </div>
        </form>
      </section>

    </body>
</html>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nfcaikur/public_html/nfcard/resources/views/order.blade.php ENDPATH**/ ?>