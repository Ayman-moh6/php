<!DOCTYPE html>
<html>
    

</html>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/nfcard/resources/views/home.blade.php ENDPATH**/ ?>